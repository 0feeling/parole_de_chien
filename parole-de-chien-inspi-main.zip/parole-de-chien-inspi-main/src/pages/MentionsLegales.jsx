export default function MentionsLegales() {
  return <div>MentionsLegales</div>;
}
