export default function PolitiquesConfidentialites() {
  return <div>PolitiquesConfidentialites</div>;
}
