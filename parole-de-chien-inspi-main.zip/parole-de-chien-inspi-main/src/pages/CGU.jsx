export default function CGU() {
  return <div>CGU</div>;
}
