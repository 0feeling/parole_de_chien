export default function ConfirmPayment() {
  return (
    <div className="text-5xl font-bold h-96 text-center">
      Le paiement a bien été effectué !
    </div>
  );
}
